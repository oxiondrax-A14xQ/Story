"""
AniMind — FastAPI entry point  (main.py)
-----------------------------------------
Run:   uvicorn main:app --reload --port 8000
Docs:  http://localhost:8000/docs
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from animind_config   import settings          
from animind_database import init_db           
from animind_routers import (           
    auth_router,
    chat_router,
    mood_router,
    booking_router,
    insights_router,
    clinician_router,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()   # create tables on startup
    yield


app = FastAPI(
    title="AniMind API",
    description="AI-powered mental health platform",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router,      prefix="/api/v1/auth",      tags=["Auth"])
app.include_router(chat_router,      prefix="/api/v1/chat",      tags=["Chat"])
app.include_router(mood_router,      prefix="/api/v1/mood",      tags=["Mood"])
app.include_router(booking_router,   prefix="/api/v1/booking",   tags=["Booking"])
app.include_router(insights_router,  prefix="/api/v1/insights",  tags=["Insights"])
app.include_router(clinician_router, prefix="/api/v1/clinician", tags=["Clinician"])


@app.get("/health", tags=["Health"])
async def health():
    return {"status": "ok", "version": "1.0.0"}
