"""
core/config.py
--------------
App settings loaded from environment variables / .env file.
All other modules import `settings` from here.
"""

from __future__ import annotations
from typing import List
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────
    APP_NAME: str = "AniMind"
    SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION_USE_32_CHARS"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440   # 24 h
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # ── Database ─────────────────────────────────────────
    DATABASE_URL: str = "sqlite+aiosqlite:///./animind.db"

    # ── Redis ────────────────────────────────────────────DATABASE_URL: str = "sqlite+aiosqlite:///./animind.db"
    REDIS_URL: str = "redis://localhost:6379"
    SESSION_TTL: int = 3600                   # seconds

    # ── OpenAI ───────────────────────────────────────────
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o"
    WHISPER_MODEL: str = "whisper-1"

    # ── Risk thresholds ───────────────────────────────────
    RISK_MODERATE: int = 31                   # score >= this → moderate
    RISK_HIGH: int = 71                       # score >= this → high / escalate

    # ── CORS ─────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "https://animind.app",
    ]

    # ── Email alerts ─────────────────────────────────────
    SMTP_HOST: str = "smtp.sendgrid.net"
    SMTP_PORT: int = 587
    SMTP_USER: str = "apikey"
    SMTP_PASS: str = ""
    ALERT_FROM_EMAIL: str = "alerts@animind.app"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Single shared instance imported everywhere
settings = Settings()
