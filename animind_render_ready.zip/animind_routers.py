"""
routers/all_routers.py
-----------------------
All six AniMind API routers, each exported as a named variable:

  auth_router      → /api/v1/auth
  chat_router      → /api/v1/chat
  mood_router      → /api/v1/mood
  booking_router   → /api/v1/booking
  insights_router  → /api/v1/insights
  clinician_router → /api/v1/clinician
"""

from __future__ import annotations
from datetime import datetime, timedelta
from typing import Optional
import uuid

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, UploadFile, status
from pydantic import BaseModel, EmailStr, Field, UUID4

from animind_ai_engine import (          
    run_chat_pipeline,
    transcribe_voice,
    generate_weekly_insight,
)
from animind_security import get_current_user_id   # ← correct package import


# ════════════════════════════════════════════════════════════════
# SCHEMAS
# ════════════════════════════════════════════════════════════════

class RegisterIn(BaseModel):
    email:    EmailStr
    password: str      = Field(min_length=8)
    language: str      = "en"
    region:   Optional[str] = None

class LoginIn(BaseModel):
    email:    EmailStr
    password: str

class TokenOut(BaseModel):
    access_token:  str
    refresh_token: str
    token_type:    str = "bearer"

class UserOut(BaseModel):
    id:         UUID4
    email:      str
    language:   str
    region:     Optional[str]
    risk_level: str
    created_at: datetime

class ChatIn(BaseModel):
    content:         str       = Field(min_length=1, max_length=2000)
    conversation_id: Optional[UUID4] = None

class ChatOut(BaseModel):
    message_id:      UUID4
    conversation_id: UUID4
    ai_response:     str
    risk_level:      str
    risk_score:      int
    sentiment_score: float
    intent:          str
    escalated:       bool
    timestamp:       datetime

class MoodIn(BaseModel):
    mood_score: int = Field(ge=0, le=100)

class MoodTrendOut(BaseModel):
    period:            str
    entries:           list[dict]
    average_score:     float
    trend_direction:   str
    weekly_change_pct: float

class PHQ9In(BaseModel):
    answers: list[int] = Field(min_length=9, max_length=9)

class GAD7In(BaseModel):
    answers: list[int] = Field(min_length=7, max_length=7)

class AssessmentOut(BaseModel):
    score:          int
    severity:       str
    recommendation: str
    timestamp:      datetime

class PsychologistOut(BaseModel):
    id:              UUID4
    name:            str
    specialization:  str
    rating:          float
    languages:       list[str]
    available_slots: list[str]

class BookIn(BaseModel):
    psychologist_id: UUID4
    scheduled_time:  datetime
    notes:           Optional[str] = None

class AppointmentOut(BaseModel):
    id:                UUID4
    psychologist_name: str
    scheduled_time:    datetime
    status:            str

class InsightOut(BaseModel):
    summary:      str
    risk_score:   int
    risk_level:   str
    mood_trend:   list[dict]
    generated_at: datetime

class PatientOut(BaseModel):
    user_id:            UUID4
    email:              str
    risk_level:         str
    current_mood_score: Optional[float]
    last_active:        Optional[datetime]
    phq9_latest:        Optional[int]
    gad7_latest:        Optional[int]


# ════════════════════════════════════════════════════════════════
# AUTH
# ════════════════════════════════════════════════════════════════
auth_router = APIRouter()

@auth_router.post("/register", response_model=TokenOut, status_code=201)
async def register(body: RegisterIn):
    """Register a new user. Returns JWT access + refresh tokens."""
    # TODO: check unique email, hash password, insert User + UserProfile to DB
    return TokenOut(
        access_token  = "eyJ.access.sig",
        refresh_token = "eyJ.refresh.sig",
    )

@auth_router.post("/login", response_model=TokenOut)
async def login(body: LoginIn):
    """Validate credentials and return JWT tokens."""
    # TODO: fetch user, verify_password(), create_access_token(user.id)
    return TokenOut(
        access_token  = "eyJ.access.sig",
        refresh_token = "eyJ.refresh.sig",
    )

@auth_router.post("/refresh", response_model=TokenOut)
async def refresh(user_id: str = Depends(get_current_user_id)):
    """Exchange a refresh token for a new access token."""
    return TokenOut(
        access_token  = "eyJ.new_access.sig",
        refresh_token = "eyJ.new_refresh.sig",
    )

@auth_router.get("/me", response_model=UserOut)
async def get_me(user_id: str = Depends(get_current_user_id)):
    """Return the authenticated user's profile."""
    return UserOut(
        id=uuid.UUID(user_id), email="user@example.com",
        language="hi", region="IN-MH",
        risk_level="normal", created_at=datetime.utcnow(),
    )


# ════════════════════════════════════════════════════════════════
# CHAT
# ════════════════════════════════════════════════════════════════
chat_router = APIRouter()

@chat_router.post("/message", response_model=ChatOut)
async def send_message(
    body: ChatIn,
    background_tasks: BackgroundTasks,
    user_id: str = Depends(get_current_user_id),
):
    """
    Full AI pipeline per message:
    1. Load conversation history from Redis / DB
    2. run_chat_pipeline → analyze_risk + generate_response + should_escalate
    3. Persist messages to DB
    4. If escalated → fire background clinician alert
    """
    history: list[dict] = []   # TODO: load from Redis cache
    result = await run_chat_pipeline(body.content, history)

    if result["escalate"]:
        background_tasks.add_task(_fire_clinician_alert, user_id, result)

    conv_id = body.conversation_id or uuid.uuid4()
    return ChatOut(
        message_id=uuid.uuid4(), conversation_id=conv_id,
        ai_response=result["ai_response"],
        risk_level=result["risk_level"],   risk_score=result["risk_score"],
        sentiment_score=result["sentiment_score"], intent=result["intent"],
        escalated=result["escalate"],      timestamp=datetime.utcnow(),
    )

@chat_router.get("/history/{conversation_id}")
async def get_history(
    conversation_id: uuid.UUID,
    user_id: str = Depends(get_current_user_id),
):
    """Return all messages for a conversation, ordered chronologically."""
    return {
        "conversation_id": str(conversation_id),
        "messages": [
            {
                "id": str(uuid.uuid4()), "sender_type": "ai",
                "content": "Hey! How are you feeling today? 🌿",
                "timestamp": datetime.utcnow().isoformat(),
                "sentiment_score": 0.6, "risk_flag": False,
            }
        ],
    }

@chat_router.get("/conversations")
async def list_conversations(user_id: str = Depends(get_current_user_id)):
    return {"conversations": [{"id": str(uuid.uuid4()), "created_at": datetime.utcnow().isoformat(), "message_count": 14}]}

@chat_router.post("/voice")
async def voice_chat(
    audio: UploadFile = File(...),
    user_id: str = Depends(get_current_user_id),
):
    """Transcribe audio via Whisper; pass result to POST /chat/message."""
    audio_bytes = await audio.read()
    text = await transcribe_voice(audio_bytes, audio.filename or "audio.webm")
    return {"transcription": text}


# ════════════════════════════════════════════════════════════════
# MOOD
# ════════════════════════════════════════════════════════════════
mood_router = APIRouter()

@mood_router.post("/log", status_code=201)
async def log_mood(body: MoodIn, user_id: str = Depends(get_current_user_id)):
    return {"id": str(uuid.uuid4()), "mood_score": body.mood_score, "timestamp": datetime.utcnow().isoformat()}

@mood_router.get("/trend", response_model=MoodTrendOut)
async def mood_trend(period: str = "weekly", user_id: str = Depends(get_current_user_id)):
    mock = [
        {"date": "2025-02-20", "score": 50}, {"date": "2025-02-21", "score": 40},
        {"date": "2025-02-22", "score": 65}, {"date": "2025-02-23", "score": 60},
        {"date": "2025-02-24", "score": 45}, {"date": "2025-02-25", "score": 80},
        {"date": "2025-02-26", "score": 72},
    ]
    return MoodTrendOut(period=period, entries=mock, average_score=58.9,
                        trend_direction="improving", weekly_change_pct=18.2)

@mood_router.post("/phq9", response_model=AssessmentOut, status_code=201)
async def submit_phq9(body: PHQ9In, user_id: str = Depends(get_current_user_id)):
    total = sum(body.answers)
    sev, rec = _phq9_interpret(total)
    return AssessmentOut(score=total, severity=sev, recommendation=rec, timestamp=datetime.utcnow())

@mood_router.post("/gad7", response_model=AssessmentOut, status_code=201)
async def submit_gad7(body: GAD7In, user_id: str = Depends(get_current_user_id)):
    total = sum(body.answers)
    sev, rec = _gad7_interpret(total)
    return AssessmentOut(score=total, severity=sev, recommendation=rec, timestamp=datetime.utcnow())


# ════════════════════════════════════════════════════════════════
# BOOKING
# ════════════════════════════════════════════════════════════════
booking_router = APIRouter()

@booking_router.get("/psychologists", response_model=list[PsychologistOut])
async def list_psychologists(
    specialization: Optional[str] = None,
    language: Optional[str] = None,
    user_id: str = Depends(get_current_user_id),
):
    return [
        PsychologistOut(id=uuid.uuid4(), name="Dr. Ananya Sharma",
            specialization="Anxiety & Depression CBT", rating=4.9,
            languages=["en", "hi"], available_slots=["2025-03-01T10:00Z", "2025-03-01T15:00Z"]),
        PsychologistOut(id=uuid.uuid4(), name="Dr. Rajan Mehta",
            specialization="Trauma & Stress Management", rating=4.8,
            languages=["en", "hi", "mr"], available_slots=["2025-03-01T14:00Z"]),
    ]

@booking_router.post("/book", response_model=AppointmentOut, status_code=201)
async def book_appointment(body: BookIn, user_id: str = Depends(get_current_user_id)):
    return AppointmentOut(id=uuid.uuid4(), psychologist_name="Dr. Ananya Sharma",
                          scheduled_time=body.scheduled_time, status="pending")

@booking_router.get("/appointments", response_model=list[AppointmentOut])
async def get_appointments(user_id: str = Depends(get_current_user_id)):
    return [AppointmentOut(id=uuid.uuid4(), psychologist_name="Dr. Ananya Sharma",
                           scheduled_time=datetime(2025, 3, 1, 10, 0), status="confirmed")]

@booking_router.patch("/appointments/{appointment_id}/cancel")
async def cancel_appointment(appointment_id: uuid.UUID, user_id: str = Depends(get_current_user_id)):
    return {"id": str(appointment_id), "status": "cancelled"}


# ════════════════════════════════════════════════════════════════
# INSIGHTS
# ════════════════════════════════════════════════════════════════
insights_router = APIRouter()

@insights_router.get("/weekly", response_model=InsightOut)
async def weekly_insight(user_id: str = Depends(get_current_user_id)):
    trend = [50, 40, 65, 60, 45, 80, 72]
    summary = await generate_weekly_insight(
        mood_trend=trend, phq9_latest=8, gad7_latest=5, weekly_change_pct=18.2
    )
    return InsightOut(summary=summary, risk_score=22, risk_level="normal",
                      mood_trend=[{"day": i + 1, "score": s} for i, s in enumerate(trend)],
                      generated_at=datetime.utcnow())

@insights_router.get("/risk-history")
async def risk_history(days: int = 30, user_id: str = Depends(get_current_user_id)):
    return {"days": days, "history": [
        {"date": "2025-02-20", "risk_score": 45, "risk_level": "moderate"},
        {"date": "2025-02-23", "risk_score": 28, "risk_level": "normal"},
        {"date": "2025-02-26", "risk_score": 22, "risk_level": "normal"},
    ]}


# ════════════════════════════════════════════════════════════════
# CLINICIAN
# ════════════════════════════════════════════════════════════════
clinician_router = APIRouter()

@clinician_router.get("/patients", response_model=list[PatientOut])
async def get_patients(risk_filter: Optional[str] = None, clinician_id: str = Depends(get_current_user_id)):
    return [PatientOut(user_id=uuid.uuid4(), email="patient@example.com",
                       risk_level="high", current_mood_score=28.0,
                       last_active=datetime.utcnow() - timedelta(hours=2),
                       phq9_latest=18, gad7_latest=14)]

@clinician_router.get("/patients/{user_id}/conversations")
async def patient_conversations(user_id: uuid.UUID, clinician_id: str = Depends(get_current_user_id)):
    return {"user_id": str(user_id), "conversations": [
        {"conversation_id": str(uuid.uuid4()),
         "created_at": (datetime.utcnow() - timedelta(days=1)).isoformat(),
         "message_count": 24, "peak_risk_score": 78, "has_risk_flags": True,
         "snippet": "User expressed feelings of hopelessness related to academic pressure..."}
    ]}

@clinician_router.post("/patients/{user_id}/message")
async def message_patient(user_id: uuid.UUID, body: dict, clinician_id: str = Depends(get_current_user_id)):
    return {"status": "sent", "to": str(user_id), "content": body.get("content")}

@clinician_router.patch("/patients/{user_id}/resolve")
async def resolve_alert(user_id: uuid.UUID, clinician_id: str = Depends(get_current_user_id)):
    return {"status": "resolved", "user_id": str(user_id)}


# ════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════

def _phq9_interpret(score: int) -> tuple[str, str]:
    if score <= 4:   return "Minimal depression",           "Continue daily mood tracking."
    if score <= 9:   return "Mild depression",              "Try the mindfulness modules in AniMind."
    if score <= 14:  return "Moderate depression",          "We recommend speaking with a psychologist."
    if score <= 19:  return "Moderately severe depression", "Please book an urgent session."
    return             "Severe depression",                 "Please contact a professional immediately."

def _gad7_interpret(score: int) -> tuple[str, str]:
    if score <= 4:   return "Minimal anxiety",  "Your anxiety levels are within a healthy range."
    if score <= 9:   return "Mild anxiety",     "Try the grounding exercises in AniMind."
    if score <= 14:  return "Moderate anxiety", "A check-in with a therapist is recommended."
    return             "Severe anxiety",        "Please speak with a psychologist soon."

async def _fire_clinician_alert(user_id: str, risk_data: dict) -> None:
    """
    Background task: write ClinicianAlert row + push WebSocket event.
    TODO: INSERT into clinician_alerts, emit WS event, send email if offline.
    """
    print(
        f"[ALERT] user={user_id} "
        f"score={risk_data['risk_score']} "
        f"flags={risk_data.get('risk_flags', [])}"
    )
