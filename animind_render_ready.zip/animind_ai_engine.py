"""
core/ai_engine.py
-----------------
AniMind AI chatbot pipeline.

STAGES PER MESSAGE
──────────────────
  1. analyze_risk()          → intent, sentiment, risk score, flags
  2. generate_response()     → CBT-guided reply, tone-adapted to risk level
  3. should_escalate()       → bool — fire clinician alert?
  4. run_chat_pipeline()     → orchestrates all three, single public entry-point

RISK SCORE GUIDE
────────────────
   0 – 30 : normal    → standard CBT conversation
  31 – 70 : moderate  → grounding techniques + suggest therapy
  71 – 100: high      → crisis resources + clinician alert
"""

from __future__ import annotations
import json
import io

from openai import AsyncOpenAI

from animind_config import settings   # ← correct import

client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)


# ── System prompts ────────────────────────────────────────────────

_CBT_PROMPT = """
You are AniMind, a compassionate AI mental health companion trained in
Cognitive Behavioural Therapy (CBT). Be warm, non-judgmental, and brief.

Rules:
• Acknowledge feelings before offering techniques.
• Use CBT naturally — thought records, behavioural activation,
  grounding (5-4-3-2-1), breathing (4-7-8), Socratic questions.
• Keep replies to 2–4 sentences unless the user is in distress.
• Never diagnose or prescribe. Never claim to be human.
• On suicidal ideation / immediate danger, ALWAYS say:
  "Please reach out to iCall: 9152987821 or NIMHANS: 080-46110007.
   You deserve real support right now."
• Respond in the user's language when detected.
"""

_RISK_PROMPT = """
Analyse the conversation and return ONLY valid JSON — no prose, no markdown.

Schema:
{
  "risk_score":        <int 0–100>,
  "sentiment_score":   <float –1.0 to 1.0>,
  "intent":            <"emotional_support"|"cbt_guidance"|"crisis"|"information"|"grounding">,
  "risk_flags":        [<string>, ...],
  "escalate":          <true|false>,
  "detected_language": <ISO 639-1 code>
}

Score guide:
   0–30  normal    (everyday stress, mild sadness)
  31–70  moderate  (persistent low mood, anxiety affecting daily life)
  71–100 high      (suicidal ideation, self-harm, psychosis, acute crisis)

Possible flags: suicidal_ideation | self_harm | substance_abuse |
                psychosis_indicators | severe_depression | panic_attack |
                domestic_abuse | eating_disorder

Set escalate=true when score >= 71 OR any critical flag is present
(suicidal_ideation, self_harm, psychosis_indicators).
"""

_INSIGHT_PROMPT = """
Generate a personalised 3-sentence weekly wellness summary.
Tone: warm, encouraging, specific. Plain text only — no lists, no markdown.
"""


# ── Stage 1: Risk analysis ────────────────────────────────────────

async def analyze_risk(message: str, history: list[dict]) -> dict:
    """
    Returns risk metadata dict:
      risk_score, sentiment_score, intent, risk_flags, escalate, detected_language
    """
    context = "\n".join(
        f"{m['role'].upper()}: {m['content']}" for m in history[-6:]
    ) or "(no prior context)"

    response = await client.chat.completions.create(
        model=settings.OPENAI_MODEL,
        temperature=0,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": _RISK_PROMPT},
            {"role": "user",   "content": f"Context:\n{context}\n\nNew message: {message}"},
        ],
    )

    data = json.loads(response.choices[0].message.content)

    # Clamp and set defaults defensively
    data["risk_score"]      = max(0, min(100, int(data.get("risk_score", 0))))
    data["sentiment_score"] = max(-1.0, min(1.0, float(data.get("sentiment_score", 0))))
    data.setdefault("intent",           "emotional_support")
    data.setdefault("risk_flags",       [])
    data.setdefault("detected_language","en")
    data.setdefault("escalate",         data["risk_score"] >= settings.RISK_HIGH)
    return data


def classify_risk_level(score: int) -> str:
    """0–30 → 'normal'  |  31–70 → 'moderate'  |  71–100 → 'high'"""
    if score < settings.RISK_MODERATE:
        return "normal"
    if score < settings.RISK_HIGH:
        return "moderate"
    return "high"


# ── Stage 2: Response generation ─────────────────────────────────

async def generate_response(
    message: str,
    history: list[dict],
    risk_analysis: dict,
) -> str:
    """Generates a CBT reply, tone-adapted to risk level."""
    level    = classify_risk_level(risk_analysis["risk_score"])
    language = risk_analysis.get("detected_language", "en")

    if level == "moderate":
        suffix = (
            "\n\nCONTEXT: Moderate distress (31–70). "
            "1. Empathise first. 2. Offer one grounding technique. "
            "3. Gently suggest speaking with a psychologist."
        )
    elif level == "high":
        suffix = (
            "\n\nCRITICAL: High risk (71–100). "
            "Lead with safety. Include crisis lines. Keep response short and calm."
        )
    else:
        suffix = ""

    lang_note = f"\n\nRespond in language: {language}" if language != "en" else ""

    response = await client.chat.completions.create(
        model=settings.OPENAI_MODEL,
        temperature=0.72,
        max_tokens=380,
        messages=[
            {"role": "system", "content": _CBT_PROMPT + suffix + lang_note},
            *history[-10:],
            {"role": "user", "content": message},
        ],
    )
    return response.choices[0].message.content.strip()


# ── Stage 3: Escalation check ─────────────────────────────────────

def should_escalate(risk_analysis: dict) -> bool:
    """True when score >= RISK_HIGH or a critical flag is present."""
    critical = {"suicidal_ideation", "self_harm", "psychosis_indicators"}
    return (
        risk_analysis["risk_score"] >= settings.RISK_HIGH
        or bool(set(risk_analysis.get("risk_flags", [])) & critical)
    )


# ── Orchestrator ──────────────────────────────────────────────────

async def run_chat_pipeline(message: str, history: list[dict]) -> dict:
    """
    Runs all three stages and returns a single result dict:
      ai_response, risk_score, risk_level, sentiment_score,
      intent, risk_flags, escalate, detected_language
    """
    risk    = await analyze_risk(message, history)
    ai_text = await generate_response(message, history, risk)
    risk["escalate"] = should_escalate(risk)

    return {
        "ai_response":       ai_text,
        "risk_score":        risk["risk_score"],
        "risk_level":        classify_risk_level(risk["risk_score"]),
        "sentiment_score":   risk["sentiment_score"],
        "intent":            risk["intent"],
        "risk_flags":        risk["risk_flags"],
        "escalate":          risk["escalate"],
        "detected_language": risk["detected_language"],
    }


# ── Weekly insight ────────────────────────────────────────────────

async def generate_weekly_insight(
    mood_trend: list[int],
    phq9_latest: int | None,
    gad7_latest: int | None,
    weekly_change_pct: float,
) -> str:
    data = (
        f"Mood scores (7 days): {mood_trend}\n"
        f"PHQ-9 latest: {phq9_latest if phq9_latest is not None else 'N/A'}\n"
        f"GAD-7 latest: {gad7_latest if gad7_latest is not None else 'N/A'}\n"
        f"Mood change vs last week: {weekly_change_pct:+.1f}%"
    )
    response = await client.chat.completions.create(
        model=settings.OPENAI_MODEL,
        temperature=0.65,
        max_tokens=140,
        messages=[
            {"role": "system", "content": _INSIGHT_PROMPT},
            {"role": "user",   "content": data},
        ],
    )
    return response.choices[0].message.content.strip()


# ── Voice transcription ───────────────────────────────────────────

async def transcribe_voice(audio_bytes: bytes, filename: str = "audio.webm") -> str:
    """Transcribes audio via Whisper. Supported: webm/mp4/mp3/wav/m4a."""
    buf = io.BytesIO(audio_bytes)
    buf.name = filename
    transcript = await client.audio.transcriptions.create(
        model=settings.WHISPER_MODEL,
        file=buf,
        response_format="text",
    )
    return transcript.strip()
