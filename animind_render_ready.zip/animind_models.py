"""
core/models.py
--------------
SQLAlchemy ORM models for all 10 AniMind database tables.
"""

from __future__ import annotations
import uuid
import enum

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, Float,
    ForeignKey, SmallInteger, String, Text, func,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import relationship

from animind_database import Base   # clean import — no circular dependency


# ── Enums ─────────────────────────────────────────────────────────

class SenderType(str, enum.Enum):
    user = "user"
    ai   = "ai"

class RiskLevel(str, enum.Enum):
    normal   = "normal"
    moderate = "moderate"
    high     = "high"

class AppointmentStatus(str, enum.Enum):
    pending   = "pending"
    confirmed = "confirmed"
    completed = "completed"
    cancelled = "cancelled"


# ── Models ────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id            = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email         = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    language      = Column(String(10), default="en")
    region        = Column(String(50))
    risk_level    = Column(Enum(RiskLevel), default=RiskLevel.normal)
    last_active   = Column(DateTime(timezone=True))

    profile       = relationship("UserProfile",  back_populates="user", uselist=False, cascade="all, delete-orphan")
    conversations = relationship("Conversation", back_populates="user", cascade="all, delete-orphan")
    mood_logs     = relationship("MoodLog",      back_populates="user", cascade="all, delete-orphan")
    phq9_scores   = relationship("PHQ9Score",    back_populates="user", cascade="all, delete-orphan")
    gad7_scores   = relationship("GAD7Score",    back_populates="user", cascade="all, delete-orphan")
    appointments  = relationship("Appointment",  back_populates="user", cascade="all, delete-orphan")
    ai_insights   = relationship("AIInsight",    back_populates="user", cascade="all, delete-orphan")


class UserProfile(Base):
    __tablename__ = "user_profiles"

    user_id        = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    age            = Column(SmallInteger)
    gender         = Column(String(30))
    occupation     = Column(String(100))
    baseline_score = Column(Float)
    current_score  = Column(Float)

    user           = relationship("User", back_populates="profile")


class Conversation(Base):
    __tablename__ = "conversations"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id    = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user       = relationship("User", back_populates="conversations")
    messages   = relationship("Message", back_populates="conversation", order_by="Message.timestamp", cascade="all, delete-orphan")


class Message(Base):
    __tablename__ = "messages"

    id              = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True)
    sender_type     = Column(Enum(SenderType), nullable=False)
    content         = Column(Text, nullable=False)
    timestamp       = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    sentiment_score = Column(Float)
    risk_flag       = Column(Boolean, default=False)

    conversation    = relationship("Conversation", back_populates="messages")


class MoodLog(Base):
    __tablename__ = "mood_logs"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id    = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    mood_score = Column(SmallInteger, nullable=False)
    timestamp  = Column(DateTime(timezone=True), server_default=func.now())

    user       = relationship("User", back_populates="mood_logs")


class PHQ9Score(Base):
    __tablename__ = "phq9_scores"

    id        = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id   = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    score     = Column(SmallInteger, nullable=False)
    answers   = Column(JSONB)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

    user      = relationship("User", back_populates="phq9_scores")


class GAD7Score(Base):
    __tablename__ = "gad7_scores"

    id        = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id   = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    score     = Column(SmallInteger, nullable=False)
    answers   = Column(JSONB)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

    user      = relationship("User", back_populates="gad7_scores")


class Psychologist(Base):
    __tablename__ = "psychologists"

    id             = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name           = Column(String(150), nullable=False)
    specialization = Column(String(200))
    availability   = Column(JSONB)
    rating         = Column(Float, default=5.0)
    languages      = Column(ARRAY(String))
    is_active      = Column(Boolean, default=True)

    appointments   = relationship("Appointment", back_populates="psychologist")


class Appointment(Base):
    __tablename__ = "appointments"

    id              = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id         = Column(UUID(as_uuid=True), ForeignKey("users.id",         ondelete="CASCADE"), nullable=False, index=True)
    psychologist_id = Column(UUID(as_uuid=True), ForeignKey("psychologists.id"),                     nullable=False, index=True)
    scheduled_time  = Column(DateTime(timezone=True), nullable=False, index=True)
    status          = Column(Enum(AppointmentStatus), default=AppointmentStatus.pending)
    notes           = Column(Text)
    created_at      = Column(DateTime(timezone=True), server_default=func.now())

    user            = relationship("User",         back_populates="appointments")
    psychologist    = relationship("Psychologist", back_populates="appointments")


class AIInsight(Base):
    __tablename__ = "ai_insights"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id    = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    risk_score = Column(SmallInteger, nullable=False)
    summary    = Column(Text)
    timestamp  = Column(DateTime(timezone=True), server_default=func.now())

    user       = relationship("User", back_populates="ai_insights")


class ClinicianAlert(Base):
    __tablename__ = "clinician_alerts"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id     = Column(UUID(as_uuid=True), ForeignKey("users.id",    ondelete="CASCADE"),  nullable=False, index=True)
    risk_score  = Column(SmallInteger, nullable=False)
    risk_flags  = Column(ARRAY(String))
    message_id  = Column(UUID(as_uuid=True), ForeignKey("messages.id", ondelete="SET NULL"), nullable=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())
    is_resolved = Column(Boolean, default=False, index=True)
    resolved_at = Column(DateTime(timezone=True))
