-- ═══════════════════════════════════════════════════════════════
-- AniMind — PostgreSQL Database Schema
-- Version : 1.0
-- Engine  : PostgreSQL 15+
-- ═══════════════════════════════════════════════════════════════

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";


-- ── ENUMS ────────────────────────────────────────────────────────

CREATE TYPE sender_type  AS ENUM ('user', 'ai');
CREATE TYPE risk_level   AS ENUM ('normal', 'moderate', 'high');
CREATE TYPE appt_status  AS ENUM ('pending', 'confirmed', 'completed', 'cancelled');


-- ── TABLES ───────────────────────────────────────────────────────

-- users
CREATE TABLE users (
    id            UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    language      VARCHAR(10)  NOT NULL DEFAULT 'en',     -- ISO 639-1
    region        VARCHAR(50),                             -- e.g. 'IN-MH'
    risk_level    risk_level   NOT NULL DEFAULT 'normal',
    last_active   TIMESTAMPTZ
);

CREATE INDEX idx_users_email       ON users (email);
CREATE INDEX idx_users_risk_level  ON users (risk_level);
CREATE INDEX idx_users_last_active ON users (last_active DESC NULLS LAST);


-- user_profiles
CREATE TABLE user_profiles (
    user_id        UUID  PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
    age            SMALLINT CHECK (age BETWEEN 13 AND 120),
    gender         VARCHAR(30),
    occupation     VARCHAR(100),
    baseline_score REAL,    -- composite at onboarding
    current_score  REAL     -- updated after each assessment
);


-- conversations
CREATE TABLE conversations (
    id         UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_conv_user_id ON conversations (user_id, created_at DESC);


-- messages
CREATE TABLE messages (
    id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    conversation_id UUID        NOT NULL REFERENCES conversations (id) ON DELETE CASCADE,
    sender_type     sender_type NOT NULL,
    content         TEXT        NOT NULL,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sentiment_score REAL        CHECK (sentiment_score BETWEEN -1.0 AND 1.0),
    risk_flag       BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_msg_conv_id   ON messages (conversation_id, timestamp);
CREATE INDEX idx_msg_risk_flag ON messages (risk_flag, timestamp DESC)
    WHERE risk_flag = TRUE;


-- mood_logs
CREATE TABLE mood_logs (
    id         UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    mood_score SMALLINT    NOT NULL CHECK (mood_score BETWEEN 0 AND 100),
    timestamp  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_mood_user_ts ON mood_logs (user_id, timestamp DESC);


-- phq9_scores  (PHQ-9 depression screening, max score 27)
CREATE TABLE phq9_scores (
    id        UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id   UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    score     SMALLINT    NOT NULL CHECK (score BETWEEN 0 AND 27),
    answers   JSONB,      -- raw [0,1,2,...] for audit trail
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_phq9_user_ts ON phq9_scores (user_id, timestamp DESC);


-- gad7_scores  (GAD-7 anxiety screening, max score 21)
CREATE TABLE gad7_scores (
    id        UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id   UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    score     SMALLINT    NOT NULL CHECK (score BETWEEN 0 AND 21),
    answers   JSONB,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_gad7_user_ts ON gad7_scores (user_id, timestamp DESC);


-- psychologists
CREATE TABLE psychologists (
    id             UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    name           VARCHAR(150) NOT NULL,
    specialization VARCHAR(200),
    availability   JSONB,                   -- {"slots": ["2025-03-01T10:00Z", ...]}
    rating         REAL         NOT NULL DEFAULT 5.0 CHECK (rating BETWEEN 0 AND 5),
    languages      TEXT[]       NOT NULL DEFAULT '{"en"}',
    is_active      BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_psychologists_active ON psychologists (is_active)
    WHERE is_active = TRUE;


-- appointments
CREATE TABLE appointments (
    id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID        NOT NULL REFERENCES users (id)         ON DELETE CASCADE,
    psychologist_id UUID        NOT NULL REFERENCES psychologists (id),
    scheduled_time  TIMESTAMPTZ NOT NULL,
    status          appt_status NOT NULL DEFAULT 'pending',
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_appt_user_id         ON appointments (user_id, scheduled_time);
CREATE INDEX idx_appt_psychologist_id ON appointments (psychologist_id, scheduled_time);
CREATE INDEX idx_appt_status          ON appointments (status, scheduled_time);


-- ai_insights  (cached weekly summaries)
CREATE TABLE ai_insights (
    id         UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    risk_score SMALLINT    NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
    summary    TEXT,
    timestamp  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_insights_user_ts ON ai_insights (user_id, timestamp DESC);


-- clinician_alerts  (escalated high-risk events)
CREATE TABLE clinician_alerts (
    id           UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    risk_score   SMALLINT    NOT NULL,
    risk_flags   TEXT[],
    message_id   UUID        REFERENCES messages (id) ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_resolved  BOOLEAN     NOT NULL DEFAULT FALSE,
    resolved_at  TIMESTAMPTZ,
    resolved_by  UUID        REFERENCES psychologists (id) ON DELETE SET NULL
);

CREATE INDEX idx_alerts_unresolved ON clinician_alerts (created_at DESC)
    WHERE is_resolved = FALSE;
CREATE INDEX idx_alerts_user_id    ON clinician_alerts (user_id, created_at DESC);


-- refresh_tokens
CREATE TABLE refresh_tokens (
    id         UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    revoked    BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_refresh_user  ON refresh_tokens (user_id);
CREATE INDEX idx_refresh_valid ON refresh_tokens (token_hash)
    WHERE revoked = FALSE;


-- ── VIEWS ────────────────────────────────────────────────────────

-- Clinician dashboard overview (latest data per patient)
CREATE OR REPLACE VIEW clinician_patient_overview AS
SELECT
    u.id              AS user_id,
    u.email,
    u.risk_level,
    u.last_active,
    u.region,
    up.age,
    up.current_score,
    ml.mood_score     AS latest_mood,
    p.score           AS latest_phq9,
    g.score           AS latest_gad7,
    (SELECT COUNT(*) FROM clinician_alerts ca
     WHERE ca.user_id = u.id AND ca.is_resolved = FALSE) AS open_alerts
FROM users u
LEFT JOIN user_profiles up ON up.user_id = u.id
LEFT JOIN LATERAL (
    SELECT mood_score FROM mood_logs
    WHERE user_id = u.id ORDER BY timestamp DESC LIMIT 1
) ml ON TRUE
LEFT JOIN LATERAL (
    SELECT score FROM phq9_scores
    WHERE user_id = u.id ORDER BY timestamp DESC LIMIT 1
) p ON TRUE
LEFT JOIN LATERAL (
    SELECT score FROM gad7_scores
    WHERE user_id = u.id ORDER BY timestamp DESC LIMIT 1
) g ON TRUE;


-- Weekly mood averages per user
CREATE OR REPLACE VIEW weekly_mood_averages AS
SELECT
    user_id,
    DATE_TRUNC('week', timestamp)        AS week_start,
    ROUND(AVG(mood_score)::NUMERIC, 1)  AS avg_mood,
    COUNT(*)                             AS log_count,
    MIN(mood_score)                      AS min_mood,
    MAX(mood_score)                      AS max_mood
FROM mood_logs
GROUP BY user_id, week_start
ORDER BY week_start DESC;


-- ── SEED DATA (dev / staging only) ──────────────────────────────

INSERT INTO psychologists (name, specialization, availability, rating, languages)
VALUES
    (
        'Dr. Ananya Sharma',
        'Anxiety & Depression (CBT)',
        '{"slots":["2025-03-01T10:00Z","2025-03-01T15:00Z","2025-03-02T11:00Z"]}',
        4.9,
        ARRAY['en','hi']
    ),
    (
        'Dr. Rajan Mehta',
        'Trauma, Stress & PTSD',
        '{"slots":["2025-03-01T14:00Z","2025-03-03T09:00Z"]}',
        4.8,
        ARRAY['en','hi','mr']
    ),
    (
        'Dr. Kavya Nair',
        'Adolescent & Young Adult Mental Health',
        '{"slots":["2025-03-04T10:00Z","2025-03-05T16:00Z"]}',
        4.7,
        ARRAY['en','ml','ta']
    );
